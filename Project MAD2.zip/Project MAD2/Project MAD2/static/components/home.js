
const home = {
    template: `<div> 
    
    Welcome to home
    
    </div>`
}

export default home